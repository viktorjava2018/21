package blackjack2;

public enum Suit {
TREFF, K�R�, K�R, PIKK
}
