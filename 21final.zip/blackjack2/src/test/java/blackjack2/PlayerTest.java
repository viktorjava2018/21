package blackjack2;

import static org.junit.Assert.assertFalse;

import java.util.ArrayList;

import org.junit.Test;

public class PlayerTest {

	@Test
	public void playerIsHaveCard() {
		//GIVEN
		
		Player player = new Player(1000);
		 Card card = new Card("KILENC", 9);
		 player.add(card);
		//WHEN
		 player.clearCards();
	}
	//THEN
	void assertFalse(player.clearCards() == null);
	}
	
	
	

// THEN

// given
// cardsot l�trehozni
// player �s card l�trehoz�sa, cardot a playernek �tadom

// when
// a playernek t�rl�m a k�rty�it

// then
// assertFalse(playerIsHaveCard) //ami az elv�rt

// olan met�dus kellene ami megvizsg�lja playernek van e k�rty�ja : true/false
// (boolean)