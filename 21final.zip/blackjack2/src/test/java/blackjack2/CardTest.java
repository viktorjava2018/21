package blackjack2;

import static org.junit.Assert.*;

import org.junit.Test;

public class CardTest {

	@Test
	public void testGetValueShouldReturnNineWhenConstructorGetNine() {
		// GIVEN
		Card card = new Card("KILENC", 9);
		//WHEN
		int result = card.getValue();
		//THEN
		assertEquals(9, result);
	}

}
